﻿using System;

namespace ConvertTimeZones
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime timeNow = DateTime.Now;
            Console.WriteLine("Enter the Required Time Zone");
            string timeZone = Console.ReadLine();

            try
            {
                string Id;
                switch (timeZone)
                {
                    case "EST":
                        Id = "Eastern Standard Time";
                        break;
                    case "PST":
                        Id = "Pacific Standard Time";
                        break;
                    case "CST":
                        Id = "Central Standard Time";
                        break;
                    default:
                        Id = String.Empty;
                        break;

                }
                if (String.IsNullOrEmpty(Id))
                    throw new ArgumentException();
                else
                {
                    TimeZoneInfo zoneToBeConverted = TimeZoneInfo.FindSystemTimeZoneById(Id);
                    DateTime newTime = TimeZoneInfo.ConvertTime(timeNow, TimeZoneInfo.Local,
                                                                    zoneToBeConverted);
                    Console.WriteLine("{0} {1} corresponds to {2} {3}.",
                                      timeNow,
                                      TimeZoneInfo.Local.IsDaylightSavingTime(timeNow) ?
                                                TimeZoneInfo.Local.DaylightName :
                                                TimeZoneInfo.Local.StandardName,
                                      newTime,
                                      zoneToBeConverted.IsDaylightSavingTime(newTime) ?
                                                  zoneToBeConverted.DaylightName :
                                                  zoneToBeConverted.StandardName);
                }
            }
            catch (TimeZoneNotFoundException)
            {
                Console.WriteLine("The input Time Zone is not found.");
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Input is not valid");
            }
            Console.ReadLine();
        }

    }
}
